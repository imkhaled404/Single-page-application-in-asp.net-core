﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineShopeSPA.Models
{
  
    public class OnlineSPADbContext : DbContext
    {
        public OnlineSPADbContext(DbContextOptions<OnlineSPADbContext> options) : base(options)
        {

        }
        public DbSet<Product> products { get; set; }
        public DbSet<Category> categories { get; set; }

    }
}
